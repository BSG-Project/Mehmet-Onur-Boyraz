$('.dateTimePicker').datetimepicker({
    dateFormat: 'yy-mm-dd'
});
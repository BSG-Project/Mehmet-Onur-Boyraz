$('.dateTimePicker').datetimepicker({
    dateFormat: 'yy-mm-dd'
    //, minDateTime: new Date()
});
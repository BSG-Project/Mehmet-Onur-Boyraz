ALTER TABLE web_user CHANGE COLUMN api_token api_password varchar(500) NULL;

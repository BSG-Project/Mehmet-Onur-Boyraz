-- https://github.com/RWTH-i5-IDSG/steve/issues/212
ALTER TABLE `connector_meter_value` MODIFY `value` TEXT;

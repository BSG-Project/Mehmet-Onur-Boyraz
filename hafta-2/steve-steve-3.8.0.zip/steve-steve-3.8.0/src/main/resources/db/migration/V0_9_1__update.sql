ALTER TABLE `connector_meter_value`
  ADD INDEX `cmv_value_timestamp_idx` (`value_timestamp` ASC)  COMMENT '';

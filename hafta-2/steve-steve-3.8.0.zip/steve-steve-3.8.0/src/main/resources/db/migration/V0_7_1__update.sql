DROP TABLE `dbVersion`;

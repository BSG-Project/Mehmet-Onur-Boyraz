DROP PROCEDURE `get_stats`;
